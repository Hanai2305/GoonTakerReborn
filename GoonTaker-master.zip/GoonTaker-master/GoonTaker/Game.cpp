#include "pch.h"
#include "Game.h"
#include <iostream>

//Basic game functions
#pragma region gameFunctions											
void Start()
{
	// initialize game resources here
	InitGameResources();
	PrintControls();
    PrintStartingSteps();
	g_MainCharacterSprite.texture.height -= 60;
	
}

void Draw()
{
	ClearBackground(0.f, 0.f, 0.f);
	
	// Put your own draw statements here
	if (g_GameStart == false && g_Level1Clear == false)
	{
		DrawStartMenu();
		DrawSelectedOption();
	}
	else if(g_GameStart == true && g_StepCounter > 0)
	{
	
		DrawFloor();
		DrawStairs(g_StairsPos);
		Point2f mainCharacterPos = ConvertToCenter(g_MainCharacterSprite, g_MainCharacterPos, 1.75f);

		for (int i{}; i < g_SpikesAmount; ++i)
		{
			DrawSpikesOnFloor(g_SpikesPositions[i]);
		}
		DrawSprite(g_MainCharacterSprite, mainCharacterPos, 1.75f, g_LookingAtRight);
		for (int i{}; i < g_VaseAmount; ++i)
		{
			g_VaseSprite.currentFrame = g_VaseFrames[i];
			DrawVase(g_VasePositions[i]);
		}
		for (int i{}; i < g_SkeletonsAmount; ++i)
		{
			DrawSkeleton(g_Skeletons[i]);
		}
		DrawWalls();
		
	}
	else if (g_GameStart == true && g_StepCounter == 0)
	{
	
		g_VasePositions[0] = Point2f{ 2, 2 };
		g_VasePositions[1] = Point2f{ 8, 3 };
		g_VasePositions[2] = Point2f{ 1, 8 };
		g_VasePositions[3] = Point2f{ 7, 8 };
		g_VasePositions[4] = Point2f{ 8, 7 };
		g_VasePositions[5] = Point2f{ 5, 5 };

		Point2f positionsOfSkeletons[] = { Point2f{7,1}, Point2f{7, 2}, Point2f{2, 3}, Point2f{5, 4 }, Point2f{5, 7} };
		for (int i{}; i < g_SkeletonsAmount; ++i)
		{
			g_Skeletons[i].pos = positionsOfSkeletons[i];
			g_Skeletons[i].animation = g_SkeletonSpriteIdle;
			g_Skeletons[i].state = AnimState::Idle;
		}
		g_Skeletons[0].pos = Point2f{ 7,1 };
		g_Skeletons[1].pos = Point2f{ 7,2 };
		g_Skeletons[2].pos = Point2f{ 2,3 };
		g_Skeletons[3].pos = Point2f{ 5,4 };
		g_Skeletons[4].pos = Point2f{ 5,7 };
		g_MainCharacterPos.x = 1;
		g_MainCharacterPos.y = 1;
		DrawDeathScreen();
		DrawSelectedOption();
	}
	if (g_Level1Clear == true && g_Level2Start == false)
	{
			DrawLevelClear();
			g_VaseAmount = 8;
			g_VasePositions[0] = Point2f{ 3, 1 };
			g_VasePositions[1] = Point2f{ 7, 2 };
			g_VasePositions[2] = Point2f{ 5, 3 };
			g_VasePositions[3] = Point2f{ 1, 4 };
			g_VasePositions[4] = Point2f{ 3, 5 };
			g_VasePositions[5] = Point2f{ 7, 6 };
			g_VasePositions[6] = Point2f{ 4, 7 };
			g_VasePositions[7] = Point2f{ 2, 8 };

			g_SkeletonsAmount = 3;
			Point2f positionsOfSkeletons[] = { Point2f{3, 3}, Point2f{6, 4}, Point2f{5, 6} };
			for (int i{}; i < g_SkeletonsAmount; ++i)
			{
				g_Skeletons[i].pos = positionsOfSkeletons[i];
				g_Skeletons[i].animation = g_SkeletonSpriteIdle;
				g_Skeletons[i].state = AnimState::Idle;
			}
			g_Skeletons[0].pos = Point2f{ 3, 3 };
			g_Skeletons[1].pos = Point2f{ 6, 4 };
			g_Skeletons[2].pos = Point2f{ 5, 6 };

			g_SpikesAmount = 9;
			g_SpikesPositions[0] = Point2f{ 6,1 };
			g_SpikesPositions[1] = Point2f{ 2,2 };
			g_SpikesPositions[2] = Point2f{ 4,2 };
			g_SpikesPositions[3] = Point2f{ 3,4 };
			g_SpikesPositions[4] = Point2f{ 7,4 };
			g_SpikesPositions[5] = Point2f{ 5,5 };
			g_SpikesPositions[6] = Point2f{ 2,6 };
			g_SpikesPositions[7] = Point2f{ 3,7 };
			g_SpikesPositions[8] = Point2f{ 6,8 };
	}
	if (g_Level2Start == true && g_StepCounter > 0)
	{
		DrawFloor();
		DrawStairs(g_StairsPos);
		Point2f mainCharacterPos = ConvertToCenter(g_MainCharacterSprite, g_MainCharacterPos, 1.75f);

		for (int i{}; i < g_SpikesAmount; ++i)
		{
			DrawSpikesOnFloor(g_SpikesPositions[i]);
		}
		DrawSprite(g_MainCharacterSprite, mainCharacterPos, 1.75f, g_LookingAtRight);
		for (int i{}; i < g_VaseAmount; ++i)
		{
			g_VaseFrames[i] = 0;
			DrawVase(g_VasePositions[i]);
		}
		for (int i{}; i < g_SkeletonsAmount; ++i)
		{
			DrawSkeleton(g_Skeletons[i]);
		}
		DrawWalls();
	}
	if (g_Level2Start == true && g_StepCounter == 0)
	{
		g_VasePositions[0] = Point2f{ 3, 1 };
		g_VasePositions[1] = Point2f{ 7, 2 };
		g_VasePositions[2] = Point2f{ 5, 3 };
		g_VasePositions[3] = Point2f{ 1, 4 };
		g_VasePositions[4] = Point2f{ 3, 5 };
		g_VasePositions[5] = Point2f{ 7, 6 };
		g_VasePositions[6] = Point2f{ 4, 7 };
		g_VasePositions[7] = Point2f{ 2, 8 };

		
		Point2f positionsOfSkeletons[] = { Point2f{3, 3}, Point2f{6, 4}, Point2f{5, 6} };
		for (int i{}; i < g_SkeletonsAmount; ++i)
		{
			g_Skeletons[i].pos = positionsOfSkeletons[i];
			g_Skeletons[i].animation = g_SkeletonSpriteIdle;
			g_Skeletons[i].state = AnimState::Idle;
		}
		g_Skeletons[0].pos = Point2f{ 3, 3 };
		g_Skeletons[1].pos = Point2f{ 6, 4 };
		g_Skeletons[2].pos = Point2f{ 5, 6 };


		g_SpikesPositions[0] = Point2f{ 6,1 };
		g_SpikesPositions[1] = Point2f{ 2,2 };
		g_SpikesPositions[2] = Point2f{ 4,2 };
		g_SpikesPositions[3] = Point2f{ 3,4 };
		g_SpikesPositions[4] = Point2f{ 7,4 };
		g_SpikesPositions[5] = Point2f{ 5,5 };
		g_SpikesPositions[6] = Point2f{ 2,6 };
		g_SpikesPositions[7] = Point2f{ 3,7 };
		g_SpikesPositions[8] = Point2f{ 6,8 };
		DrawDeathScreen();
		DrawSelectedOption();
	}
	if (g_Level2Clear == true)
	{
		DrawEnd();
	}
	
}

void Update(float elapsedSec)
{
	// process input, do physics
	switch (g_AnimStateMainCharacter)
	{
	case AnimState::Idle:
		AnimateMainCharacterIdle(elapsedSec);
		break;
	case AnimState::Attack:
		AnimatedMainCharacterAttack(elapsedSec);
		break;
	case AnimState::Run:
		AnimatedMainCharacterRun(elapsedSec);
		break;
	case AnimState::Dead:
		AnimatedMainCharacterDead(elapsedSec);
		AnimatedSpikesOnTheFloor(elapsedSec);
		break;
	}
	VaseCol(elapsedSec);
	SpikeCol(elapsedSec);
	SkeletonCol(elapsedSec);
	CoolDown(elapsedSec);

	for (int i{}; i < g_SkeletonsAmount; ++i)
	{
		if (g_Skeletons[i].state == AnimState::Dead)
		{
			if (g_Skeletons[i].animation.currentFrame < g_Skeletons[i].animation.frames - 1)
			{
				UpdateSprite(g_Skeletons[i].animation, elapsedSec);
			}
			else
			{
				g_Skeletons[i].pos = Point2f{ -1, -1 };
			}
		}
		else
		{

			g_Skeletons[i].state = AnimState::Idle;
			UpdateSprite(g_Skeletons[i].animation, elapsedSec);
		}
	}

	// e.g. Check keyboard state
	//const Uint8 *pStates = SDL_GetKeyboardState( nullptr );
	//if ( pStates[SDL_SCANCODE_RIGHT] )
	//{
	//	std::cout << "Right arrow key is down\n";
	//}
	//if ( pStates[SDL_SCANCODE_LEFT] && pStates[SDL_SCANCODE_UP])
	//{
	//	std::cout << "Left and up arrow keys are down\n";
	//}
}

void End()
{
	// free game resources here
	FreeGameResources();
}
#pragma endregion gameFunctions

//Keyboard and mouse input handling
#pragma region inputHandling											
void OnKeyDownEvent(SDL_Keycode key)
{
	
	if (g_GameStart == true && g_StepCounter > 0 || g_Level2Start == true && g_StepCounter > 0)
	{
		//Return if character dead or attacking
		if (g_AnimStateMainCharacter == AnimState::Dead || g_AnimStateMainCharacter == AnimState::Attack)
		{
			return;
		}
		//Set run animation
		g_MainCharacterSprite.currentFrame = 23;
		if (g_CoolDown > 0.f)
		{
			return;
		}
		switch (key)
		{
		case SDLK_UP:
			g_CheckXas = false;
			g_LookingAtUp = true;
			g_MainCharacterPos.y--;
			g_AnimStateMainCharacter = AnimState::Run;
			g_CoolDown = 0.2f;
			g_StepCounter -= 1;
			std::cout << "Moves left: " << g_StepCounter << std::endl;
			break;
		case SDLK_DOWN:
			g_CheckXas = false;
			g_LookingAtUp = false;
			g_MainCharacterPos.y++;
			g_AnimStateMainCharacter = AnimState::Run;
			g_CoolDown = 0.2f;
			g_StepCounter -= 1;
			std::cout << "Moves left: " << g_StepCounter << std::endl;
			break;
		case SDLK_RIGHT:
			g_CheckXas = true;
			g_LookingAtRight = true;
			g_MainCharacterPos.x++;
			g_AnimStateMainCharacter = AnimState::Run;
			g_CoolDown = 0.2f;
			g_StepCounter -= 1;
			std::cout << "Moves left: " << g_StepCounter << std::endl;
			break;
		case SDLK_LEFT:
			g_CheckXas = true;
			g_LookingAtRight = false;
			g_MainCharacterPos.x--;
			g_AnimStateMainCharacter = AnimState::Run;
			g_CoolDown = 0.2f;
			g_StepCounter -= 1;
			std::cout << "Moves left: " << g_StepCounter << std::endl;
			break;
		}
		if (g_MainCharacterPos.x >= 9)
		{
			g_MainCharacterPos.x = 8;
		}
		if (g_MainCharacterPos.x <= 1)
		{
			g_MainCharacterPos.x = 1;
		}
		if (g_MainCharacterPos.y >= 9)
		{
			g_MainCharacterPos.y = 8;
		}
		if (g_MainCharacterPos.y <= 1)
		{
			g_MainCharacterPos.y = 1;
		}

		if (g_MainCharacterPos.x == 8 && g_MainCharacterPos.y == 8)
		{
			g_GameStart = false;
			g_Level1Clear = true;
		}

		if (g_MainCharacterPos.x == 8 && g_MainCharacterPos.y == 8 && g_Level2Start == true)
		{
			g_Level2Clear = true;
		}
	}
	else if (g_GameStart == false && g_Level1Clear == false || g_GameStart == true && g_StepCounter == 0)
	{

		switch (key)
		{
		case SDLK_RIGHT:
			g_StartLeft = 430.f;
			break;
		case SDLK_LEFT:
			g_StartLeft = 70.f;
			break;
		case SDLK_SPACE:
			if (g_StartLeft == 70.f)
			{
				g_GameStart = true;
				g_StepCounter = 18;
			}
			else if (g_StartLeft == 430.f)
			{
				exit(0);
			}
			break;
		}
	}
	if(g_Level2Start == true && g_StepCounter == 0)
	{
		switch (key)
		{
		case SDLK_RIGHT:
			g_StartLeft = 430.f;
			break;
		case SDLK_LEFT:
			g_StartLeft = 70.f;
			break;
		case SDLK_SPACE:
			if (g_StartLeft == 70.f)
			{
				g_StepCounter = 20;
			}
			else if (g_StartLeft == 430.f)
			{
				exit(0);
			}
			break;
		}
	}
	if (g_Level1Clear == true && g_Level2Start == false)
	{
		switch (key)
		{
		case SDLK_SPACE:
			g_StepCounter = 20;
			std::cout << std::endl;
			std::cout << "You get 20 moves this time. Good luck.";
			g_Level2Start = true;
			g_MainCharacterPos.x = 1;
			g_MainCharacterPos.y = 1;
			break;
		}
	}
	
	
}

void OnKeyUpEvent(SDL_Keycode key)
{
	//switch (key)
	//{
	//case SDLK_LEFT:
	//	//std::cout << "Left arrow key released\n";
	//	break;
	//case SDLK_RIGHT:
	//	//std::cout << "Right arrow key released\n";
	//	break;
	//case SDLK_1:
	//case SDLK_KP_1:
	//	//std::cout << "Key 1 released\n";
	//	break;
	//}
}

void OnMouseMotionEvent(const SDL_MouseMotionEvent& e)
{
	// SAMPLE CODE: print mouse position
	//const float mouseX{ float(e.x) };
	//const float mouseY{ float(e.y) };
	//std::cout << "  [" << mouseX << ", " << mouseY << "]\n";
}

void OnMouseDownEvent(const SDL_MouseButtonEvent& e)
{
	// SAMPLE CODE: print mouse position
	//const float mouseX{ float(e.x) };
	//const float mouseY{ float(e.y) };
	//std::cout << "  [" << mouseX << ", " << mouseY << "]\n";
}

void OnMouseUpEvent(const SDL_MouseButtonEvent& e)
{
	// SAMPLE CODE: print mouse position
	//const float mouseX{ float(e.x) };
	//const float mouseY{ float(e.y) };
	//std::cout << "  [" << mouseX << ", " << mouseY << "]\n";

	// SAMPLE CODE: check which mouse button was pressed
	//switch (e.button)
	//{
	//case SDL_BUTTON_LEFT:
	//	//std::cout << "Left mouse button released\n";
	//	break;
	//case SDL_BUTTON_RIGHT:
	//	//std::cout << "Right mouse button released\n";
	//	break;
	//case SDL_BUTTON_MIDDLE:
	//	//std::cout << "Middle mouse button released\n";
	//	break;
	//}
}
#pragma endregion inputHandling

#pragma region ownDefinitions
// Define your own functions here

void InitGameResources()
{
	g_SkeletonPositions = new Point2f[g_SkeletonsAmount];
	g_VasePositions = new Point2f[g_VaseAmount];
	g_VaseFrames = new int[g_VaseAmount];
	g_Skeletons = new Skeleton[g_SkeletonsAmount];
	g_SpikesPositions = new Point2f[g_SpikesAmount];

	Point2f positionsOfSkeletons[] = { Point2f{7,1}, Point2f{7, 2}, Point2f{2, 3}, Point2f{5, 4 }, Point2f{5, 7} };

	for (int i{}; i < g_VaseAmount; ++i)
	{
		g_VaseFrames[i] = 0;
	}


	g_VasePositions[0] = Point2f{ 2, 2 };
	g_VasePositions[1] = Point2f{ 8, 3 };
	g_VasePositions[2] = Point2f{ 1, 8 };
	g_VasePositions[3] = Point2f{ 7, 8 };
	g_VasePositions[4] = Point2f{ 8, 7 };
	g_VasePositions[5] = Point2f{ 5, 5 };

	g_SpikesPositions[0] = Point2f{ 2,1 };
	g_SpikesPositions[1] = Point2f{ 3,1 };
	g_SpikesPositions[2] = Point2f{ 4,3 };
	g_SpikesPositions[3] = Point2f{ 5,3 };
	g_SpikesPositions[4] = Point2f{ 6,3 };
	g_SpikesPositions[5] = Point2f{ 2,4 };
	g_SpikesPositions[6] = Point2f{ 3,4 };
	g_SpikesPositions[7] = Point2f{ 2,6 };
	g_SpikesPositions[8] = Point2f{ 4,6 };
	g_SpikesPositions[9] = Point2f{ 5,6 };
	g_SpikesPositions[10] = Point2f{ 6,6 };
	g_SpikesPositions[11] = Point2f{ 7,6 };
	g_SpikesPositions[12] = Point2f{ 2,7 };
	g_SpikesPositions[13] = Point2f{ 7,7 };
	g_SpikesPositions[14] = Point2f{ 2,8 };
	g_SpikesPositions[15] = Point2f{ 5,8 };


	if (!TextureFromFile("Resources/NightBorne/NightBorne.png", g_MainCharacterSprite.texture))
	{
		std::cout << "ERROR loading main character spritesheet!\n";
	}
	g_MainCharacterSprite.frames = 23 * 5;
	g_MainCharacterSprite.cols = 23;
	g_MainCharacterSprite.frameTime = 0.075f;
	g_MainCharacterSprite.accumulatedTime = 0.f;
	g_MainCharacterSprite.currentFrame = 0;

	
	if (!TextureFromFile("Resources/Skeleton Idle.png", g_SkeletonSpriteIdle.texture))
	{
		std::cout << "ERROR loading skeleton spritesheet!\n";
	}
	g_SkeletonSpriteIdle.frames = 11;
	g_SkeletonSpriteIdle.cols = 11;
	g_SkeletonSpriteIdle.frameTime = 0.1f;
	g_SkeletonSpriteIdle.accumulatedTime = 0.f;
	g_SkeletonSpriteIdle.currentFrame = 0;

	if (!TextureFromFile("Resources/Vases_AssetPack_By_VerzatileDev/VasesAssetPackTransparent.png", g_VaseSprite.texture))
	{
		std::cout << "ERROR loading vases spritesheet!\n";
	}
	g_VaseSprite.frames = 80;
	g_VaseSprite.cols = 8;
	g_VaseSprite.frameTime = 0.1f;
	g_VaseSprite.accumulatedTime = 0.f;
	g_VaseSprite.currentFrame = 0;

	if (!TextureFromFile("Resources/Skeleton Dead.png", g_SkeletonSpriteDead.texture))
	{
		std::cout << "ERROR loading skeleton death spritesheet!\n";
	}
	g_SkeletonSpriteDead.frames = 15;
	g_SkeletonSpriteDead.cols = 15;
	g_SkeletonSpriteDead.frameTime = 0.05f;
	g_SkeletonSpriteDead.accumulatedTime = 0.f;
	g_SkeletonSpriteIdle.currentFrame = 0;


	if (!TextureFromFile("Resources/individuals files/floor.png", g_WallSprite.texture))
	{
		std::cout << "ERROR loading torch spritesheet!\n";
	}
	g_WallSprite.frames = 1;
	g_WallSprite.cols = 1;
	g_WallSprite.frameTime = 0.1f;
	g_WallSprite.accumulatedTime = 0.f;
	g_WallSprite.currentFrame = 0;

	
	if (!TextureFromFile("Resources/individuals files/StartMenu.png", g_StartMenuSprite.texture))
	{
		std::cout << "ERROR loading startmenu spritesheet!\n";
	}
	g_StartMenuSprite.frames = 1;
	g_StartMenuSprite.cols = 1;
	g_StartMenuSprite.frameTime = 0.1f;
	g_StartMenuSprite.accumulatedTime = 0.f;
	g_StartMenuSprite.currentFrame = 0;

	if (!TextureFromFile("Resources/individuals files/Topwall.png", g_TopWall))
	{
		std::cout << "ERROR loading topwall spritesheet!\n";
	}
	if (!TextureFromFile("Resources/individuals files/leftcorner.png", g_TopLeftCorner))
	{
		std::cout << "ERROR loading top left corner spritesheet!\n";
	}
	if (!TextureFromFile("Resources/individuals files/leftwall.png", g_LeftWall))
	{
		std::cout << "ERROR loading left wall spritesheet!\n";
	}
	if (!TextureFromFile("Resources/individuals files/bottomleftcorner.png", g_BottomLeftCorner))
	{
		std::cout << "ERROR loading bottom left corner spritesheet!\n";
	}
	if (!TextureFromFile("Resources/individuals files/bottomwall.png", g_BottomWall))
	{
		std::cout << "ERROR loading bottom wall spritesheet!\n";
	}
	if (!TextureFromFile("Resources/individuals files/toprightcorner.png", g_TopRightCorner))
	{
		std::cout << "ERROR loading top right corner spritesheet!\n";
	}
	if (!TextureFromFile("Resources/individuals files/rightwall.png", g_RightWall))
	{
		std::cout << "ERROR loading right wall spritesheet!\n";
	}
	if (!TextureFromFile("Resources/individuals files/bottomrightcorner.png", g_BottomRightCorner))
	{
		std::cout << "ERROR loading bottom right corner spritesheet!\n";
	}

	if (!TextureFromString("OUT OF TURNS", "Resources/individuals files/8-bit Arcade In.ttf", 110, Color4f{ 1.f, 0.2f, 0.2f, 1.f }, g_TextOutOfTurns))
	{
		std::cout << "ERROR loading 8-bit arcade font file!\n";
	}
	if (!TextureFromString("Maybe count your steps next time", "Resources/individuals files/8-bit Arcade In.ttf", 30, Color4f{ 1.f, 1.f, 1.f, 1.f }, g_TextDeathMessage))
	{
		std::cout << "ERROR loading 8-bit arcade font file!\n";
	}

	if (!TextureFromString("Level 1 Clear", "Resources/individuals files/8-bit Arcade In.ttf", 30, Color4f{ 1.f, 1.f, 1.f, 1.f }, g_TextLevelClear))
	{
		std::cout << "ERROR loading 8-bit arcade font file!\n";
	}

	if (!TextureFromString("Level 2 clear", "Resources/individuals files/8-bit Arcade In.ttf", 30, Color4f{ 1.f, 1.f, 1.f, 1.f }, g_TextEnd))
	{
		std::cout << "ERROR loading 8-bit arcade font file!\n";
	}

	if (!TextureFromFile("Resources/individuals files/DeathMenu.png", g_DeathScreen))
	{
		std::cout << "ERROR loading death screen file file!\n";
	}

	if (!TextureFromFile("Resources/individuals files/dongeonWallFloorTransparent9.png", g_WallTextureOnGrid.texture))
	{
		std::cout << "ERROR wall!\n";
	}
	

	g_WallTextureOnGrid.frames = 1;
	g_WallTextureOnGrid.cols = 1;
	g_WallTextureOnGrid.frameTime = 0.1f;
	g_WallTextureOnGrid.accumulatedTime = 0.f;
	g_WallTextureOnGrid.currentFrame = 0;

	for (int i{}; i < g_SkeletonsAmount; ++i)
	{
		g_Skeletons[i].pos = positionsOfSkeletons[i];
		g_Skeletons[i].animation = g_SkeletonSpriteIdle;
		g_Skeletons[i].state = AnimState::Idle;
	}

	if (!TextureFromFile("Resources/Dungeon tileset.png", g_DungeonTileSet.texture))
	{
		std::cout << "ERROR loading dungeon tileset spritesheet\n";
	}
	g_DungeonTileSet.frames = 288;
	g_DungeonTileSet.cols = 24;
	g_DungeonTileSet.frameTime = 0.1f;
	g_DungeonTileSet.accumulatedTime = 0.f;
	g_DungeonTileSet.currentFrame = 63;

	if (!TextureFromFile("Resources/individuals files/StairsExit.png", g_Stairs.texture))
	{
		std::cout << "ERROR loading stairs spritesheet\n";
	}
	g_Stairs.frames = 1;
	g_Stairs.cols = 1;
	g_Stairs.frameTime = 0.1f;
	g_Stairs.accumulatedTime = 0.f;
	g_Stairs.currentFrame = 0;

}
void FreeGameResources()
{
	DeleteTexture(g_SkeletonSpriteIdle.texture);
	DeleteTexture(g_WallSprite.texture);
	DeleteTexture(g_StartMenuSprite.texture);
	DeleteTexture(g_TopWall);
	DeleteTexture(g_TopLeftCorner);
	DeleteTexture(g_LeftWall);
	DeleteTexture(g_BottomLeftCorner);
	DeleteTexture(g_BottomWall);
	DeleteTexture(g_TopRightCorner);
	DeleteTexture(g_RightWall);
	DeleteTexture(g_BottomRightCorner);
	DeleteTexture(g_TextOutOfTurns);
	DeleteTexture(g_TextDeathMessage);
	DeleteTexture(g_DeathScreen);
	DeleteTexture(g_TextLevelClear);

	DeleteTexture(g_MainCharacterSprite.texture);
	DeleteTexture(g_WallSprite.texture);
	DeleteTexture(g_VaseSprite.texture);
	DeleteTexture(g_SkeletonSpriteIdle.texture);
	DeleteTexture(g_SkeletonSpriteDead.texture);
	DeleteTexture(g_DungeonTileSet.texture);
	DeleteTexture(g_Stairs.texture);
	delete[] g_VasePositions;
	delete[] g_VaseFrames;
	delete[] g_SkeletonPositions;
}
void DrawSprite(const Sprite& sprite, Point2f& pos, float scale, bool flipping)
{
	int rows = sprite.frames / sprite.cols;

	float widthSprite = sprite.texture.width / sprite.cols;
	float heightSprite = sprite.texture.height / rows;

	int frame = sprite.currentFrame;
	int col = frame % sprite.cols;
	int row = frame / sprite.cols;

	Rectf src{};

	src.left = col * widthSprite;
	src.top = row * heightSprite;
	src.width = widthSprite;
	src.height = heightSprite;

	Rectf dst{};

	dst.left = pos.x;
	dst.top = pos.y;
	dst.width = widthSprite * scale;
	dst.height = heightSprite * scale;

	DrawTexture(sprite.texture, dst, src);
}

Point2f ConvertToCenter(const Sprite& sprite, Point2f pos, float scale)
{
	float cellWidth = g_WindowWidth / 10.f;
	float cellHeight = g_WindowHeight / 10.f;

	int rows = sprite.frames / sprite.cols;

	float widthSprite = (sprite.texture.width / sprite.cols) * scale;
	float heightSprite = (sprite.texture.height / rows) * scale;

	Point2f correctedPos{};

	correctedPos.x = (pos.x * cellWidth) + cellWidth / 2 - widthSprite / 2;
	correctedPos.y = (pos.y * cellHeight) + cellHeight / 2 - heightSprite / 2;

	return correctedPos;
}
void DrawFloor()
{
	float tileWidth = g_WallSprite.texture.width;
	float tileHeight = g_WallSprite.texture.height;
	float scale = g_cellSize / tileWidth;

	
	Point2f TorchPos = ConvertToCenter(g_WallSprite, g_WallPos, scale);
	float wallX = g_WallPos.x;
	float wallY = g_WallPos.y;
	
	for (int i{}; i < 10; ++i)
	{
		for (int a{}; a < 10; ++a)
		{
			Point2f TorchPos = ConvertToCenter(g_WallSprite, Point2f{ wallX, wallY }, scale);
			DrawSprite(g_WallSprite, TorchPos, scale, false);
			wallX++;
		}
		wallY++;
		wallX = 0;
	}
}
void FlipSprite()
{
	if (g_LookingAtRight == true)
	{
		g_LookingAtRight = false;
	}
	else
	{
		g_LookingAtRight = true;
	}
}

void DrawEnd()
{
	Point2f clearPos
	{
		g_WindowWidth / 2.f - g_TextEnd.width / 2.f,
		g_WindowHeight / 2.f
	};
	DrawTexture(g_TextEnd, clearPos);
}
void DrawStartMenu()
{
	const Rectf startMenuRect
	{
		0.f,
		0.f,
		g_StartMenuSprite.texture.width,
		g_StartMenuSprite.texture.height
	};
	SetColor(0.f, 0.f, 0.f);
	DrawRect(0.f, 0.f, 700.f, 700.f);
	DrawTexture(g_StartMenuSprite.texture, startMenuRect);
}
void DrawSelectedOption()
{
	float width{ 200.f }, height{ 65.f }, top{505.f};
	SetColor(1.f, 0.2f, 0.2f);
	DrawRect(g_StartLeft, top, width, height, 4.f);
}
void DrawLevelClear()
{
	Point2f clearPos
	{
		g_WindowWidth / 2.f - g_TextLevelClear.width / 2.f,
		g_WindowHeight / 2.f
	};
	DrawTexture(g_TextLevelClear, clearPos);
}
void DrawWalls()
{
	const float width{ 700.f }, height{ 50.f }, top{ 0.f }, left{ 0.f }, wallScale{ 1.6f }, amount{ 29.f }, cornerScale{2.f};
	Rectf topWallRect
	{
		0.f,
		0.f,
		g_TopWall.width * wallScale,
		g_TopWall.height * wallScale
	};
	Rectf topLeftCornerRect
	{
		0.f,
		0.f,
		g_TopLeftCorner.width * cornerScale,
		g_TopLeftCorner.height * cornerScale
	};
	Rectf bottomLeftCornerRect
	{
		0.f,
		g_WindowHeight - g_BottomLeftCorner.height,
		g_BottomLeftCorner.width * cornerScale,
		g_BottomLeftCorner.height * cornerScale
	};
	Rectf leftWallRect
	{
		0.f,
		50.f,
		g_LeftWall.width * wallScale,
		g_LeftWall.height * wallScale
	};
	Rectf bottomWallRect
	{
		g_BottomLeftCorner.width,
		g_WindowHeight - g_BottomWall.height,
		g_BottomWall.width * wallScale,
		g_BottomWall.height * wallScale
	};
	Rectf topRightCornerRect
	{
		g_WindowWidth - g_TopRightCorner.width * cornerScale,
		0.f,
		g_TopRightCorner.width * cornerScale,
		g_TopRightCorner.height * cornerScale
	};
	Rectf rightWallRect
	{
		g_WindowWidth - g_RightWall.width * wallScale,
		g_TopRightCorner.height,
		g_RightWall.width * wallScale,
		g_RightWall.height * wallScale
	};
	Rectf bottomRightCornerRect
	{
		g_WindowWidth - g_BottomRightCorner.width,
		g_WindowHeight - g_BottomRightCorner.height,
		g_BottomRightCorner.width,
		g_BottomRightCorner.height
	};

	for (int i{}; i < amount; ++i)
	{
		DrawTexture(g_TopWall, topWallRect);
		topWallRect.left += g_TopWall.width * wallScale;
	}
	for (int i{}; i < amount; ++i)
	{
		DrawTexture(g_LeftWall, leftWallRect);
		leftWallRect.top += g_LeftWall.height * wallScale;
	}
	for (int i{}; i < amount; ++i)
	{
		DrawTexture(g_BottomWall, bottomWallRect);
		bottomWallRect.left += g_BottomWall.width * wallScale;
	}
	for (int i{}; i < amount; ++i)
	{
		DrawTexture(g_RightWall, rightWallRect);
		rightWallRect.top += g_RightWall.height * wallScale;
	}
	DrawTexture(g_TopLeftCorner, topLeftCornerRect);
	DrawTexture(g_BottomLeftCorner, bottomLeftCornerRect);
	DrawTexture(g_TopRightCorner, topRightCornerRect);
	DrawTexture(g_BottomRightCorner, bottomRightCornerRect);
}

void DrawDeathScreen()
{

	const float textPos{ g_WindowHeight - 350.f };
	const Point2f titlePos
	{
		g_WindowWidth / 2.f - g_TextOutOfTurns.width / 2.f,
		125.f
	};
	const Point2f turnsPos
	{
		g_WindowWidth / 5.5f,
		textPos
	};
	const Rectf deathScreenRect
	{
		0.f,
		0.f,
		g_DeathScreen.width,
		g_DeathScreen.height
	};

	DrawTexture(g_TextOutOfTurns, titlePos);
	DrawTexture(g_TextDeathMessage, turnsPos);
	DrawTexture(g_DeathScreen, deathScreenRect);

}

void PrintStartingSteps()
{
	std::cout << "You have " << g_StepCounter <<  " steps. Make them count!\n";
}
void PrintControls()
{
	std::cout << "use arrow keys to move/select. Press space to confirm.\n";
}

void DrawVase(Point2f pos)
{
	Point2f vasePos = ConvertToCenter(g_VaseSprite, Point2f{ pos.x, pos.y }, 0.25f);
	DrawSprite(g_VaseSprite, vasePos, 0.25f, false);
}
void DrawSkeleton(const Skeleton& skeleton)
{
	Point2f centeredPos = ConvertToCenter(skeleton.animation, skeleton.pos, 2.f);
	DrawSprite(skeleton.animation, centeredPos, 2.f, false);
}
void DrawStairs(Point2f pos)
{
	Point2f stairsPos = ConvertToCenter(g_Stairs, Point2f{ pos.x, pos.y }, 1.5f);
	DrawSprite(g_Stairs, stairsPos, 1.5f, false);
}

void VaseCol(float elapsedSec)
{
	int brokenFrames{ 4 };
	for (int i{}; i < g_VaseAmount; ++i)
	{
		if (g_CheckXas)
		{
			if (g_LookingAtRight)
			{
				if (g_MainCharacterPos.x == g_VasePositions[i].x && g_MainCharacterPos.y == g_VasePositions[i].y)
				{
					g_MainCharacterSprite.currentFrame = 47;
					g_MainCharacterPos.x--;
					g_AnimStateMainCharacter = AnimState::Attack;
					g_VaseFrames[i] += 2;

					if (g_VaseFrames[i] == brokenFrames)
					{
						g_VaseFrames[i] = 0;
						g_VasePositions[i] = Point2f{ -1, -1 };
					}
				}
			}
			else if (!g_LookingAtRight)
			{
				if (g_MainCharacterPos.x == g_VasePositions[i].x && g_MainCharacterPos.y == g_VasePositions[i].y)
				{
					g_MainCharacterSprite.currentFrame = 47;
					g_MainCharacterPos.x++;
					g_AnimStateMainCharacter = AnimState::Attack;
					g_VaseFrames[i] += 2;
					if (g_VaseFrames[i] == brokenFrames)
					{
						g_VaseFrames[i] = 0;
						g_VasePositions[i] = Point2f{ -1, -1 };
					}
				}

			}
		}
		else if (!g_CheckXas)
		{
			if (g_LookingAtUp)
			{
				if (g_MainCharacterPos.x == g_VasePositions[i].x && g_MainCharacterPos.y == g_VasePositions[i].y)
				{
					g_MainCharacterSprite.currentFrame = 47;
					g_MainCharacterPos.y++;
					g_AnimStateMainCharacter = AnimState::Attack;
					g_VaseFrames[i] += 2;
					if (g_VaseFrames[i] == brokenFrames)
					{
						g_VaseFrames[i] = 0;
						g_VasePositions[i] = Point2f{ -1, -1 };
					}
				}
			}
			else if (!g_LookingAtUp)
			{
				if (g_MainCharacterPos.x == g_VasePositions[i].x && g_MainCharacterPos.y == g_VasePositions[i].y)
				{
					g_MainCharacterSprite.currentFrame = 47;
					g_MainCharacterPos.y--;
					g_AnimStateMainCharacter = AnimState::Attack;
					g_VaseFrames[i] += 2;
					if (g_VaseFrames[i] == brokenFrames)
					{
						g_VaseFrames[i] = 0;
						g_VasePositions[i] = Point2f{ -1, -1 };
					}
				}
			}

		}
	}
}
void SkeletonCol(float elapsedSec)
{
	for (int i{}; i < g_SkeletonsAmount; ++i)
	{
		if (g_CheckXas)
		{
			if (g_LookingAtRight)
			{
				if (g_MainCharacterPos.x == g_Skeletons[i].pos.x && g_MainCharacterPos.y == g_Skeletons[i].pos.y)
				{
					g_MainCharacterPos.x--;
					g_MainCharacterSprite.currentFrame = 47;
					g_AnimStateMainCharacter = AnimState::Attack;

					g_Skeletons[i].animation = g_SkeletonSpriteDead;
					g_Skeletons[i].state = AnimState::Dead;
					UpdateSprite(g_Skeletons[i].animation, elapsedSec);
				}
			}
			else if (!g_LookingAtRight)
			{
				if (g_MainCharacterPos.x == g_Skeletons[i].pos.x && g_MainCharacterPos.y == g_Skeletons[i].pos.y)
				{
					g_MainCharacterPos.x++;
					g_MainCharacterSprite.currentFrame = 47;
					g_AnimStateMainCharacter = AnimState::Attack;

					g_Skeletons[i].animation = g_SkeletonSpriteDead;
					g_Skeletons[i].state = AnimState::Dead;
					UpdateSprite(g_Skeletons[i].animation, elapsedSec);
				}
			}

		}
		if (!g_CheckXas)
		{
			if (g_LookingAtUp)
			{
				if (g_MainCharacterPos.x == g_Skeletons[i].pos.x && g_MainCharacterPos.y == g_Skeletons[i].pos.y)
				{
					g_MainCharacterPos.y++;
					g_MainCharacterSprite.currentFrame = 47;
					g_AnimStateMainCharacter = AnimState::Attack;

					g_Skeletons[i].animation = g_SkeletonSpriteDead;
					g_Skeletons[i].state = AnimState::Dead;
					UpdateSprite(g_Skeletons[i].animation, elapsedSec);
				}
			}
			if (!g_LookingAtUp)
			{
				if (g_MainCharacterPos.x == g_Skeletons[i].pos.x && g_MainCharacterPos.y == g_Skeletons[i].pos.y)
				{
					g_MainCharacterPos.y--;
					g_MainCharacterSprite.currentFrame = 47;
					g_AnimStateMainCharacter = AnimState::Attack;

					g_Skeletons[i].animation = g_SkeletonSpriteDead;
					g_Skeletons[i].state = AnimState::Dead;
					UpdateSprite(g_Skeletons[i].animation, elapsedSec);
				}
			}
		}


	}
}


void AnimatedMainCharacterAttack(const float elapsedSec)
{
	const int generalAnim{ 23 * 2 };
	const int attackAnim{ 12 };
	g_MainCharacterSprite.accumulatedTime += elapsedSec;

	if (g_MainCharacterSprite.accumulatedTime > g_MainCharacterSprite.frameTime)
	{
		g_MainCharacterSprite.currentFrame++;

		if (g_MainCharacterSprite.currentFrame >= attackAnim + generalAnim)
		{
			g_MainCharacterSprite.currentFrame = generalAnim;

			g_AnimStateMainCharacter = AnimState::Idle;
		}
		g_MainCharacterSprite.accumulatedTime -= g_MainCharacterSprite.frameTime;
	}
}
void AnimatedMainCharacterRun(const float elapsedSec)
{
	const int generalAnim{ 23 };
	const int runAnim{ 6 };
	g_MainCharacterSprite.accumulatedTime += elapsedSec;

	if (g_MainCharacterSprite.accumulatedTime > g_MainCharacterSprite.frameTime)
	{
		g_MainCharacterSprite.currentFrame++;

		if (g_MainCharacterSprite.currentFrame >= runAnim + generalAnim)
		{
			g_MainCharacterSprite.currentFrame = generalAnim;

			g_AnimStateMainCharacter = AnimState::Idle;

		}
		g_MainCharacterSprite.accumulatedTime -= g_MainCharacterSprite.frameTime;
	}
}
void AnimateMainCharacterIdle(const float elapsedSec)
{

	const int generalAnim{ 23 };
	const int idleAnim{ 9 };
	g_MainCharacterSprite.accumulatedTime += elapsedSec;
	if (g_MainCharacterSprite.accumulatedTime > g_MainCharacterSprite.frameTime)
	{
		++g_MainCharacterSprite.currentFrame %= generalAnim;
		g_MainCharacterSprite.accumulatedTime -= g_MainCharacterSprite.frameTime;
		if (g_MainCharacterSprite.currentFrame >= idleAnim)
		{
			g_MainCharacterSprite.currentFrame = 0;
		}
	}
}
void CoolDown(const float elapsedSec)
{
	if (g_CoolDown > 0.f)
	{
		g_CoolDown -= elapsedSec;
	}
}
void UpdateSprite(Sprite& sprite, float elapsedSec)
{
	sprite.accumulatedTime += elapsedSec;
	if (sprite.accumulatedTime > sprite.frameTime)
	{
		++sprite.currentFrame %= sprite.frames;
		sprite.accumulatedTime -= sprite.frameTime;
	}
}

void DrawSpikesOnFloor(Point2f pos)
{
	float scale = g_cellSize / 16.f;
	Point2f dungeonTileSetPos = ConvertToCenter(g_DungeonTileSet, Point2f{ pos.x, pos.y }, scale);
	DrawSprite(g_DungeonTileSet, dungeonTileSetPos, scale, false);
}
void SpikeCol(float elapsedSec)
{
	for (int i{}; i < g_SpikesAmount; ++i)
	{
		if (g_CheckXas)
		{
			if (g_LookingAtRight)
			{
				if (g_MainCharacterPos.x == g_SpikesPositions[i].x && g_MainCharacterPos.y == g_SpikesPositions[i].y)
				{

					if (g_AnimStateMainCharacter != AnimState::Dead)
					{
						g_AnimStateMainCharacter = AnimState::Dead;
						g_MainCharacterSprite.currentFrame = 92;

					}
				}
			}
			if (!g_LookingAtRight)
			{
				if (g_MainCharacterPos.x == g_SpikesPositions[i].x && g_MainCharacterPos.y == g_SpikesPositions[i].y)
				{

					if (g_AnimStateMainCharacter != AnimState::Dead)
					{

						g_AnimStateMainCharacter = AnimState::Dead;
						g_MainCharacterSprite.currentFrame = 92;

					}
				}
			}
		}
		else if (!g_CheckXas)
		{
			if (g_LookingAtUp)
			{
				if (g_MainCharacterPos.x == g_SpikesPositions[i].x && g_MainCharacterPos.y == g_SpikesPositions[i].y)
				{

					if (g_AnimStateMainCharacter != AnimState::Dead)
					{

						g_AnimStateMainCharacter = AnimState::Dead;
						g_MainCharacterSprite.currentFrame = 92;

					}
				}

			}
			if (!g_LookingAtUp)
			{
				if (g_MainCharacterPos.x == g_SpikesPositions[i].x && g_MainCharacterPos.y == g_SpikesPositions[i].y)
				{
					if (g_AnimStateMainCharacter != AnimState::Dead)
					{
						g_AnimStateMainCharacter = AnimState::Dead;
						g_MainCharacterSprite.currentFrame = 92;

					}
				}
			}
		}
	}
}

void AnimatedMainCharacterDead(const float elapsedSec)
{
	const int generalAnim{ 92 };
	const int deadAnim{ 23 };

	g_MainCharacterSprite.accumulatedTime += elapsedSec;

	if (g_MainCharacterSprite.accumulatedTime > g_MainCharacterSprite.frameTime)
	{
		g_MainCharacterSprite.currentFrame++;
		if (g_MainCharacterSprite.currentFrame > deadAnim + generalAnim)
		{
			g_AnimStateMainCharacter = AnimState::Idle;
			if (g_AnimStateMainCharacter != AnimState::Dead)
			{
				g_StepCounter = 0;
				g_MainCharacterPos = Point2f{ 1, 1 };

			}
		}
		g_MainCharacterSprite.accumulatedTime -= g_MainCharacterSprite.frameTime;
	}

}
void AnimatedSpikesOnTheFloor(const float elapsedSec)
{
	g_DungeonTileSet.accumulatedTime += elapsedSec;
	if (g_DungeonTileSet.accumulatedTime > g_DungeonTileSet.frameTime)
	{
		g_DungeonTileSet.currentFrame--;
		g_DungeonTileSet.accumulatedTime -= g_DungeonTileSet.frameTime;
	}
	if (g_DungeonTileSet.currentFrame <= 60)
	{
		g_DungeonTileSet.currentFrame = 63;
	}

}
#pragma endregion ownDefinitions